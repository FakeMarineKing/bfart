<?php
header("Location: ../index.php"); 
session_start();?>
    	<?php
	    	include("./../codb.php"); 
	        $points = $_GET['points'];
	        $points=trim($points);
	        $points=strip_tags($points);
	        $points=htmlspecialchars($points);
	        $res=mysqli_query($bdd,"SELECT score FROM user WHERE id=$_SESSION[user]");
	        $dat=$res->fetch_assoc();
	        $newScore=$dat['score']+$points;
	  	    mysqli_query($bdd, "UPDATE user SET score = $newScore WHERE id=$_SESSION[user]");
	  	   
		?>
