var cell = 10
var snake;
var food;

function setup(){
	var myCanvas = createCanvas(cell*30,cell*30);
	myCanvas.parent('myContainer');
	snake = new Snake();
	food = new Food();
	frameRate(15);
}

function draw(){
	background(0);
	snake.eat(food);
	snake.move();
	snake.die();
	snake.show();
	food.show();
}


function keyPressed(){
	if(keyCode === UP_ARROW) snake.way(0, -1);
	else if (keyCode === DOWN_ARROW) snake.way(0, 1);
	else if (keyCode === LEFT_ARROW) snake.way(-1, 0);
	else if (keyCode === RIGHT_ARROW) snake.way(1, 0);
}

function columns(){
	return floor(width/cell);
}

function rows(){
	return floor(height/cell);
}


