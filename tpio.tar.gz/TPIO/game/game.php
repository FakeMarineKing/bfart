<?php 
    session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Game</title>
        <style> body{padding:0; margin:0;} </style>
        <link rel="stylesheet" media="screen" type="text/css" href="style.css" />
    </head>
    <body>
        <script src="game/p5/p5.js"></script>
        <div id='myContainer'>
            <script language="javascript" type="text/javascript" src="game/Snake.js"></script>
            <script language="javascript" type="text/javascript"
            src="game/main.js"></script>
            <script language="javascript" type="text/javascript" 
            src="game/Food.js"></script>
        </div>
    </body>
</html>