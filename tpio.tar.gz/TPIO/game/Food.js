function Food(){
	this.x = Math.floor((Math.random()*30))*cell;
	this.y = Math.floor((Math.random()*30))*cell;
	

	this.init = function(){
		this.x = Math.floor((Math.random()*30))*cell;
		this.y = Math.floor((Math.random()*30))*cell;
	}

	this.show = function(){
		fill(255,0,255);
		rect(this.x,this.y,cell,cell);
	}

}

