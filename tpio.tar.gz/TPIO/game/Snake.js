function Snake(){
	this.x = cell * columns()/2;
	this.y = cell * rows() /2;
	this.xMoove = 0;
	this.yMoove = 0;
	this.tail = [];
	this.points = 0;

	this.show = function() {
		fill(0,255,0);
		rect(this.x,this.y, cell, cell);
		for(var i=0; i<this.tail.length;i++){
			rect(this.tail[i].x,
				this.tail[i].y,
				cell,cell);
		}
	}

	this.way = function(x, y){
		if(x != 0 && this.xMoove != x * -1 || y!= 0 && this.yMoove != y* -1 ||
			 this.tail.length < 1){
			this.xMoove=x;
			this.yMoove=y;
		}
	}

	this.move = function(){
		if(this.tail.length>0){
			var tailTop=this.tail.pop();
			tailTop.x = this.x;
			tailTop.y = this.y;
			this.tail.unshift(tailTop);
		}

		this.x += this.xMoove * cell;
		this.y += this.yMoove * cell;

		if(this.x>width) this.x = 0+cell;
		if(this.y>height-cell) this.y = 0+cell;

		if(this.x<0) this.x = width-cell;
		if(this.y<0) this.y = height-cell;
	
	}

	this.eat = function(food){

		if(this.x === food.x && this.y === food.y){
			food.init();
			this.points+=5;
			this.tail.push(createVector(this.x,this.y));

		}
	}

	this.die = function(){
		for(var i=0;i<this.tail.length;i++){
			if(this.x === this.tail[i].x && this.y === this.tail[i].y){
				this.tail = [];0
				alert("Vous avez gagner "+this.points+" points !!");
				location.href = "./game/addPoint.php?points="+this.points;
				this.points=0;
			}

		}
	}
}