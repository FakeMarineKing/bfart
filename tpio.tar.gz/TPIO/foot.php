<footer>
	<p>Thank you all for visiting, Join me here <a href="https://www.facebook.com/arthur.raoutii.1"><img src="fblogo.png"></a>
</footer>