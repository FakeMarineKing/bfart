<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Régles</title>
    </head>
    <body>
    	<?php include("entete.php"); ?>
		<?php include("menu.php"); ?>
		<?php include("foot.php"); ?>
		<p><br/><br/><h1>Les régles du jeux : </h1></p>
		<p>Le but du jeux et de gagner des point afin d'être recompenser a la fin de la saison ! <br/></p>
		
		<h1>Les regles liée a la communautée : </h1>

		<p>Merci de rester poli et courtois envers les autres joueur.<br/>
		De plus je vous rappelle que vous pouvez gagner des point supplémentaire grace au évaluation positive d'autres utilisateur.</p>
    </body>
</html>