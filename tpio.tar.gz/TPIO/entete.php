<link rel="stylesheet" media="screen" type="text/css" href="style.css" />
<header><a href="index.php">TTT</a></header>
